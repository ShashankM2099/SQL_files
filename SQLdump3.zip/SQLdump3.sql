DROP DATABASE IF EXISTS Architecture;
CREATE DATABASE IF NOT EXISTS Architecture;
USE Architecture;

CREATE TABLE if not exists Buildings (
    BuildingID SMALLINT AUTO_INCREMENT PRIMARY KEY not null,
    Name VARCHAR(40) not null,
    Style VARCHAR(15)not null,
    Location  VARCHAR(50)not null,
    DateOfCreation DATE not null,
    TimeFrame DATETIME not null
);

CREATE TABLE IF NOT EXISTS StructureSupport (
    Type VARCHAR(10) not null primary key,
    Material VARCHAR(10) not null,
    Height DECIMAL(3,3) not null,
    Width DECIMAL(4, 4) not null,
    Radius DECIMAL(7,5) not null,
    Special_Features VARCHAR(25) not null
);

Create table if not exists TouristPopularity (
Name varchar(40) primary key not null,
Rating INT not null,
Description varchar(200) not null,
VisitorsPerYear varchar(5),
OperatingHours TIME not null,
OperatingDays DATE not null
);
